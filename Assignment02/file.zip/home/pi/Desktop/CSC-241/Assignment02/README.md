> An assembly .s file
```
gcc file.c -S -o file.s
```
> An assembly .lst listing file
```
as -a file.s > file.lst
```
> The native ARM executable
```
gcc file.c -o file
```
> Shell Script Permissions
```
chmod +x files.sh
```