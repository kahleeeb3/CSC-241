as -g fib.asm -o fib.o
gcc -g -static fib.o -o fib
./fib
