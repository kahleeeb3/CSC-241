clear
as -g add.asm -o add.o
gcc -static -g add.o -o add
./add
